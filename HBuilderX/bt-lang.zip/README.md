# BT编程语言
这是一个用于BT编程语言的代码高亮和代码编译的扩展，方便用于开发。
官网：[https://btlang.org](https://btlang.org)

# bt Language
This is an extension for code highlighting and compilation in BT programming language, which is convenient for development.
Official website: [https://btlang.org](https://btlang.org)

## License
MIT